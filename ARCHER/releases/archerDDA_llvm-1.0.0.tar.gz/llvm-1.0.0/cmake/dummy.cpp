typedef int dummy;
